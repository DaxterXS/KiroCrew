# Memory V2 historical benchmark evidence

This archive preserves evidence from the recorded 8 September 2026 d7 benchmark. It was packaged later, on 2026-09-08T23:28:35.958102+00:00. Packaging did not run a model, benchmark or product validation. Treat this named ZIP as immutable and publish its external SHA-256 alongside it; any changed package needs a new filename and checksum.

## Contents and roles

`measurement/raw.json` is the original benchmark result, including the model and corpus identifiers, three retrieval modes, selected records, metrics and edge fixtures. Its bytes are unchanged. `provenance/run.log` is the captured console output. `provenance/execution.json` is the external execution record, and `provenance/publication.json` records publication and comparison. `publication/published-current.json` is the original Windows publication copy.

Publication adds exactly `benchmark_snapshot` and `execution`. Removing those two keys leaves the entire parsed raw result unchanged. The Git head, clean-tree assertion and timestamp in the published result were manually added as publication metadata; the benchmark harness did not generate them. They remain recorded claims, not independent proof of the historical process or whole-worktree state.

The execution record identifies local commit `d7d05392f3e6be5bc4de0b6f5abd75d669db0633`, 19:40:12 to 19:43:01 UTC on 8 September 2026, and 169.62 seconds. Its exact Windows command is preserved in `execution.json`. Original absolute paths are provenance, not portable install instructions.

## Four source snapshots and two byte representations

`source-lf/` contains four exact Git LF blobs with their repository paths: `src/kiro_crew/memory_v2.py`, `src/kiro_crew/vector_memory.py`, `src/kiro_crew/eval/bench/member_v2.py` and `src/kiro_crew/eval/bench/admission_corpus.py`. The last two include the benchmark harness and authored corpus. These four blobs are equal at local d7, local 1f5 and reviewed publication `40c3216abe7e8a420bbf9afaba65f0d1d619d6cd`. This is not a benchmark run at 40c or any later head.

The manifest separately records each archived canonical LF hash and the original recorded Windows CRLF seal. For these four files, replacing every LF byte (`0A`) with CRLF (`0D 0A`) reproduces the original seal. No carriage-return bytes occur in their archived LF forms. Do not trim whitespace, normalize Unicode, reformat files, replace execution hashes or apply this rule to unrelated files. Windows source bytes derived this way are reconstructed, not archived original checkouts.

The published JSON's Windows hash and canonical Git LF hash are also separate. The original Windows JSON is archived without conversion; its LF hash is recorded for comparison with published Git source. The raw payload has its own different hash. `manifest.json` lists SHA-256 and size for every other archive entry, including this README. Its own integrity is covered by the external ZIP checksum, not a circular self-hash.

## Earlier comparison record

`comparison/previous-current-0758.json` is an earlier post-retention publication, recorded at 07:58:45 UTC (00:58:45 PDT) on 8 September 2026. Its metadata names `fbeca1346c838b62f80fc94aa60c6c880dd36953` and says `uncommitted_changes_included: true`. Its exact retained bytes and original source seals are preserved. It is not a V1 baseline, a pre-retention baseline, a clean-commit baseline or a held-out dataset.

Removing only its `benchmark_snapshot` and `execution` fields produces the same parsed payload as the d7 raw result. It is included to make that historical comparison inspectable, not to substitute the older execution identity for d7. The earlier memory-policy and vector-store seals differ from d7; its harness and corpus seals match. Identical same-corpus results do not independently prove the timing or process of either recorded run.

## Coverage and limits

Source coverage is partial. This archive is evidence for inspecting results and four source seals, not an independently runnable copy of the entire historical d7 runtime. The harness also imports code outside these four files, including admission validation and the embedding wrapper; the vector store has further dependencies. A complete historical source-tree archive or self-contained Git bundle would be needed for a stronger source-replay claim.

A contemporaneous historical environment lock is unavailable in the examined records. Exact Python/package/native build versions and acceleration settings must not be invented from today's environment. The original harness recorded Qwen3 Embedding 0.6B, 1,024 dimensions and the GGUF model hash in the raw result. The model is not included and was not rehashed during packaging. A future execution requires a full code environment and matching model and must produce a separately attributed result.

The 0.62/0.57 floors were evaluated on the same 50-question, 100-fragment authored corpus, with 5,000 labelled pairs per mode. The modes reuse the questions. The retained result explicitly says the operating point is corpus-informed and not held-out calibration. This archive supplies no independent threshold-selection log, held-out quality evidence, answer-quality result, future-head validation or full CI result.

d7 and the partial local-validation snapshot `1f5c1319129858d6d78f9f8867d0ac2961a5a0a9` exist locally but are not ancestors of 40c. Local existence does not make public commit links work. No such links are needed to inspect this archive. Local product-test logs are outside this minimal benchmark package; it does not substantiate a complete local test suite or transfer old checks to new source.

ZIP member timestamps are a fixed packaging convention, not file creation times or execution evidence. All original inputs retain exact bytes inside the archive. The existing three DOCX/PDF reports and their source index were not changed.
